package com.cg.eb.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import com.cg.eb.dto.Consumers;
import com.cg.eb.except.BillException;
import com.cg.eb.util.DBUtil;

public class BillDAOImpl implements IBillDAO {

	Statement statement = null;
	ResultSet rsSet = null;
	PreparedStatement preparedStatement = null;
	
	@Override
	public ArrayList<Consumers> getConsumerNames() throws BillException {
		// TODO Auto-generated method stub
		
		ArrayList<Consumers> consumerNames = new ArrayList<Consumers>();
		Connection connection = DBUtil.getConnection();
		
		System.out.println("Connection="+connection);
		
		String sql = "SELECT CONSUMER_NUM,CONSUMER_NAME,ADDRESS FROM consumers";
		try {
			statement = connection.createStatement();
			rsSet = statement.executeQuery(sql);
			while (rsSet.next()) {
				Consumers consumer = new Consumers();
				consumer.setConsumer_num(rsSet.getLong("CONSUMER_NUM"));
				consumer.setConsumer_name(rsSet.getString("CONSUMER_NAME"));
				consumer.setAddress(rsSet.getString("ADDRESS"));
				consumerNames.add(consumer);
			}
		} catch (SQLException e) {
			throw new BillException("Error while database interaction:::"
					+ e.getMessage());
		}
		for (Consumers consumers : consumerNames) {
			System.out.println(consumers);
		};
		return consumerNames;
	}

	@Override
	public ArrayList<Consumers> searchConsumer(long consumer_num) throws BillException {
		// TODO Auto-generated method stub
		ArrayList<Consumers> consumerRes = new ArrayList<Consumers>();
		Connection connection = DBUtil.getConnection();
		String sql = "SELECT CONSUMER_NUM,CONSUMER_NAME,ADDRESS FROM consumers WHERE CONSUMER_NUM=?";
		try {
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setLong(1, consumer_num);
			rsSet = preparedStatement.executeQuery();
			
			while (rsSet.next()) {

				Consumers consumer = new Consumers();
				consumer.setConsumer_num(rsSet.getLong("CONSUMER_NUM"));
				consumer.setConsumer_name(rsSet.getString("CONSUMER_NAME"));
				consumer.setAddress(rsSet.getString("ADDRESS"));
				consumerRes.add(consumer);
			}
			
			for (Consumers consumers : consumerRes) {
				System.out.println(consumers);
			}
		} catch (SQLException e) {
			throw new BillException("Error while database interaction:::"
					+ e.getMessage());
		}

		return consumerRes;
	}

	

	
}
