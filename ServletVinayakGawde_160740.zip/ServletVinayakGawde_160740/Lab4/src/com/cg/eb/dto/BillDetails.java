package com.cg.eb.dto;

import java.sql.Date;

public class BillDetails {
	
	private long bill_num;
	private long consumer_num;
	private double cur_reading;
	private double unitConsumed;
	private double netAmount;
	private Date bill_date;
	
	public BillDetails() {
		// TODO Auto-generated constructor stub
	}

	public BillDetails(long bill_num, long consumer_num, double cur_reading, double unitConsumed, double netAmount,
			Date bill_date) {
		super();
		this.bill_num = bill_num;
		this.consumer_num = consumer_num;
		this.cur_reading = cur_reading;
		this.unitConsumed = unitConsumed;
		this.netAmount = netAmount;
		this.bill_date = bill_date;
	}

	public long getBill_num() {
		return bill_num;
	}

	public void setBill_num(long bill_num) {
		this.bill_num = bill_num;
	}

	public long getConsumer_num() {
		return consumer_num;
	}

	public void setConsumer_num(long consumer_num) {
		this.consumer_num = consumer_num;
	}

	public double getCur_reading() {
		return cur_reading;
	}

	public void setCur_reading(double cur_reading) {
		this.cur_reading = cur_reading;
	}

	public double getUnitConsumed() {
		return unitConsumed;
	}

	public void setUnitConsumed(double unitConsumed) {
		this.unitConsumed = unitConsumed;
	}

	public double getNetAmount() {
		return netAmount;
	}

	public void setNetAmount(double netAmount) {
		this.netAmount = netAmount;
	}

	public Date getBill_date() {
		return bill_date;
	}

	public void setBill_date(Date bill_date) {
		this.bill_date = bill_date;
	}

	@Override
	public String toString() {
		return "BillDetails [bill_num=" + bill_num + ", consumer_num=" + consumer_num + ", cur_reading=" + cur_reading
				+ ", unitConsumed=" + unitConsumed + ", netAmount=" + netAmount + ", bill_date=" + bill_date + "]";
	}
	
	


}
